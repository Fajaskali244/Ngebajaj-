from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
CORS(app)

# Configure SQLite DB
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///orders.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Order Model
class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    pickup = db.Column(db.String(200))
    destination = db.Column(db.String(200))
    status = db.Column(db.String(50), default='Menunggu')

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/supir')
def supir():
    return render_template('supir.html')

@app.route('/order', methods=['POST'])
def create_order():
    data = request.json
    new_order = Order(
        name=data.get('name'),
        pickup=data.get('pickup'),
        destination=data.get('destination')
    )
    db.session.add(new_order)
    db.session.commit()
    return jsonify({"message": "Pesanan diterima"}), 201

@app.route('/orders', methods=['GET'])
def get_orders():
    orders = Order.query.all()
    return jsonify([{
        "id": o.id,
        "name": o.name,
        "pickup": o.pickup,
        "destination": o.destination,
        "status": o.status
    } for o in orders])

@app.route('/accept_order/<int:order_id>', methods=['PUT'])
def accept_order(order_id):
    order = Order.query.get(order_id)
    if order:
        order.status = 'Sedang dijemput'
        db.session.commit()
        return jsonify({"message": "Pesanan diterima"})
    return jsonify({"error": "Pesanan tidak ditemukan"}), 404

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=81)
